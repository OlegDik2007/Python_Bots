# LIKE4LIKE-BOT-USING-PYTHON
 Use This Simple Python BOT That Automates like4like.org to Gain Free Credits
 
## Run Python Code
- Make sure first to download [Python](https://www.python.org/downloads/) & this text editor [Visual Studio Code](https://code.visualstudio.com/download)
- Install all the necessary libraries using this one command: `pip install -r requirements.txt`
- Install [Cookie-Editor Extension](https://chrome.google.com/webstore/detail/cookie-editor/hlkenndednhfkekhgcdicdfddnkalmdm) in your chrome browser
- Login to your account in [Like4Like](https://www.like4like.org/) & Export the cookies using Cookie Editor Extension
- Paste the exported cookies in `cookies.json` file & change the value of `sameSite` to `'Strict'` or `'Lax'`
- Open this python file `run.py` & change `twitter_user`, `twitter_pwd` to your personal infos
- Open your `Command Prompt`and run the script using this simple command: `python run.py`
- Enjoy Gaining FREE CREDITS!

## Watch This Full Tutorial Video on How to Use LIKE4LIKE-BOT
- Follow Step By Step This [Youtube Video Tutorial](https://youtu.be/UTusr2FG2mA)
